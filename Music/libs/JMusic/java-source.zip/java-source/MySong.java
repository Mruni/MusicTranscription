import jm.music.data.*;
import jm.JMC;
import jm.util.*;
import jm.JMC;

public class MySong {
  public static void main(String [] args) {
  }
}
