public class Greeter  
{
  public static void main(String[] argv) 
  { 
    // show the string "Hello World" on the console 
    System.out.println("Hello World");
  }
}